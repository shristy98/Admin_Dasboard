﻿using CRUD_OPERATION_WEBAPI.DataContext;
using CRUD_OPERATION_WEBAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD_OPERATION_WEBAPI.Controllers
{
    [Route("api/[Controller]")]
    public class ShopApiController : Controller
    {

        private ShpoDbContext _context;
        public ShopApiController(ShpoDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public List<Shop> Get()
        {
            return _context.Shops.ToList();
        }
        [HttpGet("{Id}")]
        public Shop GeList(int Id)
        {
            var data = _context.Shops.Where(a => a.ID == Id).FirstOrDefault();
            return data;
        }

        [HttpPost]
        public IActionResult Post([FromBody] Shop data)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.Shops.Add(data);
            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            var data = await _context.Shops.FindAsync(Id);
            if (data == null)
            {
                return NotFound();
            }
            _context.Shops.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpPut("{Id}")]

        public async Task<IActionResult> Edit(int Id,  Shop data)
        {

            if (Id != data.ID)
            {
                return BadRequest("Id mismatch");
            }
            var result = await _context.Shops.FindAsync(Id);
            if (result != null)
            {
                result.ID = data.ID;
                result.Product = data.Product;
                result.Price = data.Price;
                await _context.SaveChangesAsync();
                return Ok();


            }
            return NoContent();
        }








            //public async Task<Shop> Update( Shop data)
            //{
            //    var result = await _context.Shops.FirstOrDefaultAsync(a => a.ID == data.ID);
            //    if (result != null)
            //    {
            //        result.ID = data.ID;
            //        result.Product = data.Product;
            //        result.Price = data.Price;
            //        await _context.SaveChangesAsync();
            //        return result;

            //    }
            //    return null;
            //}
        }
            }