﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CRUD_OPERATION_MVC.Helper
{
    public class ShopAPI
    {
        
      
        public HttpClient FClient()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44398/");
            return client;
        }
    }
}
